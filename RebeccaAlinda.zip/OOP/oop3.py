from oop import Vehicle

class Truck(Vehicle):
    def __init__(self, color, trailer = True):
        super(). __init__ (color)
        self.trailer = trailer

    def toString(self):
        return super().toString() + " Has trailer: " + str(self.trailer)
    

purple_without_trailer = Truck("purple,", False)
print(purple_without_trailer.toString())
neon_with_trailer = Truck("neon_orange,")
print(neon_with_trailer.toString())