class Customer:
    def __init__(self, name, address):
        self.name = name
        self.address = address
    
    def your_name(self):
        return self.name
    
    def your_address(self):
        return self.address
    

customer = Customer('Alex', '189 Dew St.')
print(customer.your_name())
print(customer.your_address())