from oop import Vehicle

class Car(Vehicle):
    def __init__(self, color, winter_tires = False):
        super().__init__(color)
        self.winter_tires = winter_tires

    def toString(self):
        return super().toString() + " and has winter tires: " + str(self.winter_tires)
    

purple_and_winter = Car("Purple", True)
print(purple_and_winter.toString())
without_winter_tires = Car("Maroon")
print(without_winter_tires.toString())