from oop import Vehicle
from oop3 import Truck
from oop4 import Garage

class GarageTester:
    def getExample(self):
        black_truck = Truck ("black", False)
        garage = Garage()
        garage.setVehicle(black_truck)
        return garage
    
to_test = GarageTester()
pearl = to_test.getExample()
print(pearl.toString())