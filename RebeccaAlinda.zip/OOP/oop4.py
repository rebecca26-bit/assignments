from oop import Vehicle
from oop2 import Car
from oop3 import Truck


class Garage(Vehicle):
    def __init__(self):
        self.vehicle_parked = None
    
    def setVehicle(self, vehicle_parked):
        self.vehicle_parked = vehicle_parked

    def toString(self):
        if self.vehicle_parked:
            return f"Description of the parked vehicle: {self.vehicle_parked.toString()}"
        else:
            return "No vehicle in the garage at the moment."
        

purple_vehicle = Truck("purple", False)
maroon_car = Car("maroon")

Pearl_garage = Garage()
Pearl_garage.setVehicle(maroon_car)
print(Pearl_garage.toString())

Pearl_garage.setVehicle(purple_vehicle)
print(Pearl_garage.toString())
