class Vehicle:
    def __init__(self, color):
        self.color = color
    
    def getColour(self):
        return self.color
    
    def toString(self):
        return f"The vehicle is {self.color}"

vehicle = Vehicle("purple")
outlook = vehicle.toString()
print(outlook)
